var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "99758",
        "ok": "74752",
        "ko": "25006"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21282",
        "ok": "21282",
        "ko": "20680"
    },
    "meanResponseTime": {
        "total": "3226",
        "ok": "2302",
        "ko": "5989"
    },
    "standardDeviation": {
        "total": "4781",
        "ok": "4103",
        "ko": "5538"
    },
    "percentiles1": {
        "total": "152",
        "ok": "73",
        "ko": "5274"
    },
    "percentiles2": {
        "total": "6066",
        "ok": "2353",
        "ko": "11171"
    },
    "percentiles3": {
        "total": "12632",
        "ok": "10469",
        "ko": "14825"
    },
    "percentiles4": {
        "total": "16552",
        "ok": "18433",
        "ko": "16148"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 49981,
    "percentage": 50
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1429,
    "percentage": 1
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 23342,
    "percentage": 23
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 25006,
    "percentage": 25
},
    "meanNumberOfRequestsPerSecond": {
        "total": "459.714",
        "ok": "344.479",
        "ko": "115.235"
    }
},
contents: {
"req_criac-a-o-ce502": {
        type: "REQUEST",
        name: "criação",
path: "criação",
pathFormatted: "req_criac-a-o-ce502",
stats: {
    "name": "criação",
    "numberOfRequests": {
        "total": "54635",
        "ok": "37584",
        "ko": "17051"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21278",
        "ok": "21278",
        "ko": "20680"
    },
    "meanResponseTime": {
        "total": "4095",
        "ok": "3142",
        "ko": "6196"
    },
    "standardDeviation": {
        "total": "5076",
        "ok": "4570",
        "ko": "5486"
    },
    "percentiles1": {
        "total": "1098",
        "ok": "321",
        "ko": "5565"
    },
    "percentiles2": {
        "total": "9096",
        "ok": "5896",
        "ko": "11215"
    },
    "percentiles3": {
        "total": "13952",
        "ok": "11410",
        "ko": "14844"
    },
    "percentiles4": {
        "total": "18242",
        "ok": "19264",
        "ko": "16171"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 21030,
    "percentage": 38
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 850,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 15704,
    "percentage": 29
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 17051,
    "percentage": 31
},
    "meanNumberOfRequestsPerSecond": {
        "total": "251.774",
        "ok": "173.198",
        "ko": "78.576"
    }
}
    },"req_busca-inva-lida-b5618": {
        type: "REQUEST",
        name: "busca inválida",
path: "busca inválida",
pathFormatted: "req_busca-inva-lida-b5618",
stats: {
    "name": "busca inválida",
    "numberOfRequests": {
        "total": "4190",
        "ok": "3504",
        "ko": "686"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21043",
        "ok": "21043",
        "ko": "11937"
    },
    "meanResponseTime": {
        "total": "1071",
        "ok": "898",
        "ko": "1955"
    },
    "standardDeviation": {
        "total": "2934",
        "ok": "2950",
        "ko": "2682"
    },
    "percentiles1": {
        "total": "10",
        "ok": "6",
        "ko": "428"
    },
    "percentiles2": {
        "total": "269",
        "ok": "109",
        "ko": "3173"
    },
    "percentiles3": {
        "total": "6919",
        "ok": "6899",
        "ko": "6926"
    },
    "percentiles4": {
        "total": "14427",
        "ok": "14996",
        "ko": "11367"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3064,
    "percentage": 73
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 65,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 375,
    "percentage": 9
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 686,
    "percentage": 16
},
    "meanNumberOfRequestsPerSecond": {
        "total": "19.309",
        "ok": "16.147",
        "ko": "3.161"
    }
}
    },"req_busca-va-lida-d7f0d": {
        type: "REQUEST",
        name: "busca válida",
path: "busca válida",
pathFormatted: "req_busca-va-lida-d7f0d",
stats: {
    "name": "busca válida",
    "numberOfRequests": {
        "total": "9590",
        "ok": "6573",
        "ko": "3017"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21282",
        "ok": "21282",
        "ko": "17449"
    },
    "meanResponseTime": {
        "total": "4291",
        "ok": "3313",
        "ko": "6421"
    },
    "standardDeviation": {
        "total": "5103",
        "ok": "4573",
        "ko": "5532"
    },
    "percentiles1": {
        "total": "1537",
        "ok": "483",
        "ko": "6346"
    },
    "percentiles2": {
        "total": "9395",
        "ok": "6187",
        "ko": "11284"
    },
    "percentiles3": {
        "total": "13876",
        "ok": "11769",
        "ko": "14874"
    },
    "percentiles4": {
        "total": "17304",
        "ok": "18951",
        "ko": "16178"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3476,
    "percentage": 36
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 171,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2926,
    "percentage": 31
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3017,
    "percentage": 31
},
    "meanNumberOfRequestsPerSecond": {
        "total": "44.194",
        "ok": "30.29",
        "ko": "13.903"
    }
}
    },"req_consulta-5d76b": {
        type: "REQUEST",
        name: "consulta",
path: "consulta",
pathFormatted: "req_consulta-5d76b",
stats: {
    "name": "consulta",
    "numberOfRequests": {
        "total": "31343",
        "ok": "27091",
        "ko": "4252"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "21002",
        "ok": "21002",
        "ko": "19920"
    },
    "meanResponseTime": {
        "total": "1674",
        "ok": "1072",
        "ko": "5505"
    },
    "standardDeviation": {
        "total": "3745",
        "ok": "2878",
        "ko": "5796"
    },
    "percentiles1": {
        "total": "8",
        "ok": "4",
        "ko": "686"
    },
    "percentiles2": {
        "total": "393",
        "ok": "125",
        "ko": "11168"
    },
    "percentiles3": {
        "total": "10994",
        "ok": "9206",
        "ko": "14896"
    },
    "percentiles4": {
        "total": "15097",
        "ok": "11559",
        "ko": "15567"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 22411,
    "percentage": 72
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 343,
    "percentage": 1
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4337,
    "percentage": 14
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 4252,
    "percentage": 14
},
    "meanNumberOfRequestsPerSecond": {
        "total": "144.438",
        "ok": "124.843",
        "ko": "19.594"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
