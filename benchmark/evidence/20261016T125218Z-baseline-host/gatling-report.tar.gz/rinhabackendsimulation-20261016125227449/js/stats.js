var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "75995",
        "ok": "23550",
        "ko": "52445"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "55"
    },
    "maxResponseTime": {
        "total": "28960",
        "ok": "28960",
        "ko": "23313"
    },
    "meanResponseTime": {
        "total": "7576",
        "ok": "3199",
        "ko": "9542"
    },
    "standardDeviation": {
        "total": "4553",
        "ok": "4632",
        "ko": "2816"
    },
    "percentiles1": {
        "total": "10001",
        "ok": "55",
        "ko": "10015"
    },
    "percentiles2": {
        "total": "10249",
        "ok": "8741",
        "ko": "10526"
    },
    "percentiles3": {
        "total": "12815",
        "ok": "10815",
        "ko": "13109"
    },
    "percentiles4": {
        "total": "14389",
        "ok": "13878",
        "ko": "14605"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14626,
    "percentage": 19
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 415,
    "percentage": 1
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8509,
    "percentage": 11
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 52445,
    "percentage": 69
},
    "meanNumberOfRequestsPerSecond": {
        "total": "350.207",
        "ok": "108.525",
        "ko": "241.682"
    }
},
contents: {
"req_busca-inva-lida-b5618": {
        type: "REQUEST",
        name: "busca inválida",
path: "busca inválida",
pathFormatted: "req_busca-inva-lida-b5618",
stats: {
    "name": "busca inválida",
    "numberOfRequests": {
        "total": "4190",
        "ok": "3994",
        "ko": "196"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "331"
    },
    "maxResponseTime": {
        "total": "11842",
        "ok": "11842",
        "ko": "10309"
    },
    "meanResponseTime": {
        "total": "656",
        "ok": "451",
        "ko": "4840"
    },
    "standardDeviation": {
        "total": "1853",
        "ok": "1517",
        "ko": "2855"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "4766"
    },
    "percentiles2": {
        "total": "114",
        "ok": "64",
        "ko": "7649"
    },
    "percentiles3": {
        "total": "4811",
        "ok": "2464",
        "ko": "8901"
    },
    "percentiles4": {
        "total": "9672",
        "ok": "8681",
        "ko": "10052"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3536,
    "percentage": 84
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 97,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 361,
    "percentage": 9
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 196,
    "percentage": 5
},
    "meanNumberOfRequestsPerSecond": {
        "total": "19.309",
        "ok": "18.406",
        "ko": "0.903"
    }
}
    },"req_busca-va-lida-d7f0d": {
        type: "REQUEST",
        name: "busca válida",
path: "busca válida",
pathFormatted: "req_busca-va-lida-d7f0d",
stats: {
    "name": "busca válida",
    "numberOfRequests": {
        "total": "9590",
        "ok": "1682",
        "ko": "7908"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "56"
    },
    "maxResponseTime": {
        "total": "28960",
        "ok": "28960",
        "ko": "18237"
    },
    "meanResponseTime": {
        "total": "9010",
        "ok": "6634",
        "ko": "9516"
    },
    "standardDeviation": {
        "total": "3815",
        "ok": "6387",
        "ko": "2742"
    },
    "percentiles1": {
        "total": "10012",
        "ok": "5883",
        "ko": "10017"
    },
    "percentiles2": {
        "total": "10735",
        "ok": "12098",
        "ko": "10535"
    },
    "percentiles3": {
        "total": "13390",
        "ok": "16013",
        "ko": "12969"
    },
    "percentiles4": {
        "total": "15889",
        "ok": "21600",
        "ko": "14105"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 645,
    "percentage": 7
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 27,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1010,
    "percentage": 11
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 7908,
    "percentage": 82
},
    "meanNumberOfRequestsPerSecond": {
        "total": "44.194",
        "ok": "7.751",
        "ko": "36.442"
    }
}
    },"req_criac-a-o-ce502": {
        type: "REQUEST",
        name: "criação",
path: "criação",
pathFormatted: "req_criac-a-o-ce502",
stats: {
    "name": "criação",
    "numberOfRequests": {
        "total": "54625",
        "ok": "13660",
        "ko": "40965"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "55"
    },
    "maxResponseTime": {
        "total": "20136",
        "ok": "18192",
        "ko": "20136"
    },
    "meanResponseTime": {
        "total": "7986",
        "ok": "3641",
        "ko": "9435"
    },
    "standardDeviation": {
        "total": "4206",
        "ok": "4689",
        "ko": "2805"
    },
    "percentiles1": {
        "total": "10002",
        "ok": "135",
        "ko": "10013"
    },
    "percentiles2": {
        "total": "10293",
        "ok": "10012",
        "ko": "10514"
    },
    "percentiles3": {
        "total": "12647",
        "ok": "10575",
        "ko": "12963"
    },
    "percentiles4": {
        "total": "13944",
        "ok": "12045",
        "ko": "14079"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 7866,
    "percentage": 14
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 243,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 5551,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 40965,
    "percentage": 75
},
    "meanNumberOfRequestsPerSecond": {
        "total": "251.728",
        "ok": "62.949",
        "ko": "188.779"
    }
}
    },"req_consulta-5d76b": {
        type: "REQUEST",
        name: "consulta",
path: "consulta",
pathFormatted: "req_consulta-5d76b",
stats: {
    "name": "consulta",
    "numberOfRequests": {
        "total": "7590",
        "ok": "4214",
        "ko": "3376"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "10000"
    },
    "maxResponseTime": {
        "total": "23313",
        "ok": "16871",
        "ko": "23313"
    },
    "meanResponseTime": {
        "total": "6638",
        "ok": "3001",
        "ko": "11179"
    },
    "standardDeviation": {
        "total": "5364",
        "ok": "4200",
        "ko": "2350"
    },
    "percentiles1": {
        "total": "9997",
        "ok": "72",
        "ko": "10043"
    },
    "percentiles2": {
        "total": "10045",
        "ok": "7073",
        "ko": "10852"
    },
    "percentiles3": {
        "total": "13736",
        "ok": "10067",
        "ko": "17046"
    },
    "percentiles4": {
        "total": "18963",
        "ok": "10238",
        "ko": "20522"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2579,
    "percentage": 34
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 48,
    "percentage": 1
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1587,
    "percentage": 21
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3376,
    "percentage": 44
},
    "meanNumberOfRequestsPerSecond": {
        "total": "34.977",
        "ok": "19.419",
        "ko": "15.558"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
