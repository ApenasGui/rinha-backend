var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "72298",
        "ok": "10216",
        "ko": "62082"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "20595",
        "ok": "20595",
        "ko": "13637"
    },
    "meanResponseTime": {
        "total": "955",
        "ok": "2167",
        "ko": "756"
    },
    "standardDeviation": {
        "total": "2632",
        "ok": "3657",
        "ko": "2364"
    },
    "percentiles1": {
        "total": "0",
        "ok": "18",
        "ko": "0"
    },
    "percentiles2": {
        "total": "5",
        "ok": "3753",
        "ko": "1"
    },
    "percentiles3": {
        "total": "9249",
        "ok": "10092",
        "ko": "7980"
    },
    "percentiles4": {
        "total": "10135",
        "ok": "11428",
        "ko": "10045"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 7122,
    "percentage": 10
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 120,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 2974,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 62082,
    "percentage": 86
},
    "meanNumberOfRequestsPerSecond": {
        "total": "352.673",
        "ok": "49.834",
        "ko": "302.839"
    }
},
contents: {
"req_busca-inva-lida-b5618": {
        type: "REQUEST",
        name: "busca inválida",
path: "busca inválida",
pathFormatted: "req_busca-inva-lida-b5618",
stats: {
    "name": "busca inválida",
    "numberOfRequests": {
        "total": "4190",
        "ok": "1086",
        "ko": "3104"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "767",
        "ok": "767",
        "ko": "217"
    },
    "meanResponseTime": {
        "total": "5",
        "ok": "17",
        "ko": "2"
    },
    "standardDeviation": {
        "total": "33",
        "ok": "62",
        "ko": "8"
    },
    "percentiles1": {
        "total": "0",
        "ok": "2",
        "ko": "0"
    },
    "percentiles2": {
        "total": "2",
        "ok": "6",
        "ko": "1"
    },
    "percentiles3": {
        "total": "14",
        "ok": "75",
        "ko": "10"
    },
    "percentiles4": {
        "total": "105",
        "ok": "306",
        "ko": "16"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1086,
    "percentage": 26
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3104,
    "percentage": 74
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.439",
        "ok": "5.298",
        "ko": "15.141"
    }
}
    },"req_busca-va-lida-d7f0d": {
        type: "REQUEST",
        name: "busca válida",
path: "busca válida",
pathFormatted: "req_busca-va-lida-d7f0d",
stats: {
    "name": "busca válida",
    "numberOfRequests": {
        "total": "9590",
        "ok": "955",
        "ko": "8635"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "3",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "14479",
        "ok": "14479",
        "ko": "13637"
    },
    "meanResponseTime": {
        "total": "1068",
        "ok": "2972",
        "ko": "857"
    },
    "standardDeviation": {
        "total": "2799",
        "ok": "4163",
        "ko": "2518"
    },
    "percentiles1": {
        "total": "0",
        "ok": "338",
        "ko": "0"
    },
    "percentiles2": {
        "total": "9",
        "ok": "5342",
        "ko": "1"
    },
    "percentiles3": {
        "total": "9742",
        "ok": "11686",
        "ko": "8757"
    },
    "percentiles4": {
        "total": "11153",
        "ok": "13557",
        "ko": "10084"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 547,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 46,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 362,
    "percentage": 4
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 8635,
    "percentage": 90
},
    "meanNumberOfRequestsPerSecond": {
        "total": "46.78",
        "ok": "4.659",
        "ko": "42.122"
    }
}
    },"req_criac-a-o-ce502": {
        type: "REQUEST",
        name: "criação",
path: "criação",
pathFormatted: "req_criac-a-o-ce502",
stats: {
    "name": "criação",
    "numberOfRequests": {
        "total": "54615",
        "ok": "5196",
        "ko": "49419"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "11035",
        "ok": "11035",
        "ko": "10741"
    },
    "meanResponseTime": {
        "total": "843",
        "ok": "2443",
        "ko": "675"
    },
    "standardDeviation": {
        "total": "2462",
        "ok": "3697",
        "ko": "2228"
    },
    "percentiles1": {
        "total": "0",
        "ok": "52",
        "ko": "0"
    },
    "percentiles2": {
        "total": "2",
        "ok": "4591",
        "ko": "1"
    },
    "percentiles3": {
        "total": "8417",
        "ok": "10107",
        "ko": "7099"
    },
    "percentiles4": {
        "total": "10098",
        "ok": "10395",
        "ko": "10028"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3394,
    "percentage": 6
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 46,
    "percentage": 0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1756,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 49419,
    "percentage": 90
},
    "meanNumberOfRequestsPerSecond": {
        "total": "266.415",
        "ok": "25.346",
        "ko": "241.068"
    }
}
    },"req_consulta-5d76b": {
        type: "REQUEST",
        name: "consulta",
path: "consulta",
pathFormatted: "req_consulta-5d76b",
stats: {
    "name": "consulta",
    "numberOfRequests": {
        "total": "3903",
        "ok": "2979",
        "ko": "924"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "164"
    },
    "maxResponseTime": {
        "total": "20595",
        "ok": "20595",
        "ko": "10336"
    },
    "meanResponseTime": {
        "total": "3267",
        "ok": "2211",
        "ko": "6671"
    },
    "standardDeviation": {
        "total": "4215",
        "ok": "3798",
        "ko": "3652"
    },
    "percentiles1": {
        "total": "194",
        "ok": "38",
        "ko": "8155"
    },
    "percentiles2": {
        "total": "7081",
        "ok": "3790",
        "ko": "10003"
    },
    "percentiles3": {
        "total": "10054",
        "ok": "9996",
        "ko": "10087"
    },
    "percentiles4": {
        "total": "12901",
        "ok": "13916",
        "ko": "10207"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2095,
    "percentage": 54
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 28,
    "percentage": 1
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 856,
    "percentage": 22
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 924,
    "percentage": 24
},
    "meanNumberOfRequestsPerSecond": {
        "total": "19.039",
        "ok": "14.532",
        "ko": "4.507"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
