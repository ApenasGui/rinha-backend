var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "100175",
        "ok": "77940",
        "ko": "22235"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "14355",
        "ok": "14355",
        "ko": "13058"
    },
    "meanResponseTime": {
        "total": "5026",
        "ok": "3484",
        "ko": "10431"
    },
    "standardDeviation": {
        "total": "4867",
        "ok": "4379",
        "ko": "1388"
    },
    "percentiles1": {
        "total": "2939",
        "ok": "483",
        "ko": "10386"
    },
    "percentiles2": {
        "total": "10121",
        "ok": "9380",
        "ko": "10783"
    },
    "percentiles3": {
        "total": "10952",
        "ok": "10449",
        "ko": "12155"
    },
    "percentiles4": {
        "total": "12256",
        "ok": "11115",
        "ko": "12760"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 41162,
    "percentage": 41
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1948,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 34830,
    "percentage": 35
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 22235,
    "percentage": 22
},
    "meanNumberOfRequestsPerSecond": {
        "total": "459.518",
        "ok": "357.523",
        "ko": "101.995"
    }
},
contents: {
"req_busca-inva-lida-b5618": {
        type: "REQUEST",
        name: "busca inválida",
path: "busca inválida",
pathFormatted: "req_busca-inva-lida-b5618",
stats: {
    "name": "busca inválida",
    "numberOfRequests": {
        "total": "4190",
        "ok": "4170",
        "ko": "20"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "3024",
        "ok": "3024",
        "ko": "442"
    },
    "meanResponseTime": {
        "total": "197",
        "ok": "197",
        "ko": "192"
    },
    "standardDeviation": {
        "total": "429",
        "ok": "430",
        "ko": "166"
    },
    "percentiles1": {
        "total": "4",
        "ok": "4",
        "ko": "209"
    },
    "percentiles2": {
        "total": "141",
        "ok": "137",
        "ko": "373"
    },
    "percentiles3": {
        "total": "1145",
        "ok": "1146",
        "ko": "419"
    },
    "percentiles4": {
        "total": "2081",
        "ok": "2093",
        "ko": "437"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3816,
    "percentage": 91
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 162,
    "percentage": 4
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 192,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 20,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "19.22",
        "ok": "19.128",
        "ko": "0.092"
    }
}
    },"req_busca-va-lida-d7f0d": {
        type: "REQUEST",
        name: "busca válida",
path: "busca válida",
pathFormatted: "req_busca-va-lida-d7f0d",
stats: {
    "name": "busca válida",
    "numberOfRequests": {
        "total": "9590",
        "ok": "6601",
        "ko": "2989"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "1",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "14023",
        "ok": "14023",
        "ko": "13053"
    },
    "meanResponseTime": {
        "total": "6909",
        "ok": "5312",
        "ko": "10435"
    },
    "standardDeviation": {
        "total": "4535",
        "ok": "4576",
        "ko": "1298"
    },
    "percentiles1": {
        "total": "10002",
        "ok": "4593",
        "ko": "10367"
    },
    "percentiles2": {
        "total": "10352",
        "ok": "10092",
        "ko": "10768"
    },
    "percentiles3": {
        "total": "11164",
        "ok": "10785",
        "ko": "12128"
    },
    "percentiles4": {
        "total": "12386",
        "ok": "11646",
        "ko": "12764"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2046,
    "percentage": 21
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 194,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4361,
    "percentage": 45
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2989,
    "percentage": 31
},
    "meanNumberOfRequestsPerSecond": {
        "total": "43.991",
        "ok": "30.28",
        "ko": "13.711"
    }
}
    },"req_criac-a-o-ce502": {
        type: "REQUEST",
        name: "criação",
path: "criação",
pathFormatted: "req_criac-a-o-ce502",
stats: {
    "name": "criação",
    "numberOfRequests": {
        "total": "54647",
        "ok": "39103",
        "ko": "15544"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "14355",
        "ok": "14355",
        "ko": "13058"
    },
    "meanResponseTime": {
        "total": "6326",
        "ok": "4702",
        "ko": "10409"
    },
    "standardDeviation": {
        "total": "4710",
        "ok": "4575",
        "ko": "1422"
    },
    "percentiles1": {
        "total": "9846",
        "ok": "2513",
        "ko": "10376"
    },
    "percentiles2": {
        "total": "10235",
        "ok": "9993",
        "ko": "10777"
    },
    "percentiles3": {
        "total": "11061",
        "ok": "10576",
        "ko": "12123"
    },
    "percentiles4": {
        "total": "12290",
        "ok": "11355",
        "ko": "12714"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14987,
    "percentage": 27
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1126,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 22990,
    "percentage": 42
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15544,
    "percentage": 28
},
    "meanNumberOfRequestsPerSecond": {
        "total": "250.674",
        "ok": "179.372",
        "ko": "71.303"
    }
}
    },"req_consulta-5d76b": {
        type: "REQUEST",
        name: "consulta",
path: "consulta",
pathFormatted: "req_consulta-5d76b",
stats: {
    "name": "consulta",
    "numberOfRequests": {
        "total": "31748",
        "ok": "28066",
        "ko": "3682"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "0"
    },
    "maxResponseTime": {
        "total": "13588",
        "ok": "13588",
        "ko": "12998"
    },
    "meanResponseTime": {
        "total": "2856",
        "ok": "1844",
        "ko": "10575"
    },
    "standardDeviation": {
        "total": "4307",
        "ok": "3463",
        "ko": "1066"
    },
    "percentiles1": {
        "total": "69",
        "ok": "7",
        "ko": "10462"
    },
    "percentiles2": {
        "total": "6322",
        "ok": "1418",
        "ko": "10811"
    },
    "percentiles3": {
        "total": "10693",
        "ok": "10060",
        "ko": "12393"
    },
    "percentiles4": {
        "total": "11899",
        "ok": "10692",
        "ko": "12789"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 20313,
    "percentage": 64
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 466,
    "percentage": 1
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7287,
    "percentage": 23
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3682,
    "percentage": 12
},
    "meanNumberOfRequestsPerSecond": {
        "total": "145.633",
        "ok": "128.743",
        "ko": "16.89"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
