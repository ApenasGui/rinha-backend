var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "98368",
        "ok": "75567",
        "ko": "22801"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "46"
    },
    "maxResponseTime": {
        "total": "23478",
        "ok": "21348",
        "ko": "23478"
    },
    "meanResponseTime": {
        "total": "4086",
        "ok": "2911",
        "ko": "7980"
    },
    "standardDeviation": {
        "total": "4551",
        "ok": "4131",
        "ko": "3613"
    },
    "percentiles1": {
        "total": "1320",
        "ok": "359",
        "ko": "10001"
    },
    "percentiles2": {
        "total": "9660",
        "ok": "5488",
        "ko": "10345"
    },
    "percentiles3": {
        "total": "10985",
        "ok": "10383",
        "ko": "11676"
    },
    "percentiles4": {
        "total": "12853",
        "ok": "12607",
        "ko": "15852"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 43841,
    "percentage": 45
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 3055,
    "percentage": 3
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 28671,
    "percentage": 29
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 22801,
    "percentage": 23
},
    "meanNumberOfRequestsPerSecond": {
        "total": "451.229",
        "ok": "346.638",
        "ko": "104.592"
    }
},
contents: {
"req_busca-inva-lida-b5618": {
        type: "REQUEST",
        name: "busca inválida",
path: "busca inválida",
pathFormatted: "req_busca-inva-lida-b5618",
stats: {
    "name": "busca inválida",
    "numberOfRequests": {
        "total": "4190",
        "ok": "4176",
        "ko": "14"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "68"
    },
    "maxResponseTime": {
        "total": "5944",
        "ok": "5944",
        "ko": "626"
    },
    "meanResponseTime": {
        "total": "241",
        "ok": "241",
        "ko": "314"
    },
    "standardDeviation": {
        "total": "672",
        "ok": "673",
        "ko": "184"
    },
    "percentiles1": {
        "total": "2",
        "ok": "2",
        "ko": "306"
    },
    "percentiles2": {
        "total": "66",
        "ok": "64",
        "ko": "458"
    },
    "percentiles3": {
        "total": "1634",
        "ok": "1638",
        "ko": "601"
    },
    "percentiles4": {
        "total": "3271",
        "ok": "3272",
        "ko": "621"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3783,
    "percentage": 90
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 122,
    "percentage": 3
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 271,
    "percentage": 6
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 14,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "19.22",
        "ok": "19.156",
        "ko": "0.064"
    }
}
    },"req_busca-va-lida-d7f0d": {
        type: "REQUEST",
        name: "busca válida",
path: "busca válida",
pathFormatted: "req_busca-va-lida-d7f0d",
stats: {
    "name": "busca válida",
    "numberOfRequests": {
        "total": "9590",
        "ok": "6292",
        "ko": "3298"
    },
    "minResponseTime": {
        "total": "1",
        "ok": "1",
        "ko": "59"
    },
    "maxResponseTime": {
        "total": "16069",
        "ok": "16069",
        "ko": "16000"
    },
    "meanResponseTime": {
        "total": "5559",
        "ok": "4455",
        "ko": "7666"
    },
    "standardDeviation": {
        "total": "4443",
        "ok": "4484",
        "ko": "3501"
    },
    "percentiles1": {
        "total": "5517",
        "ok": "2314",
        "ko": "9581"
    },
    "percentiles2": {
        "total": "10057",
        "ok": "9758",
        "ko": "10309"
    },
    "percentiles3": {
        "total": "11234",
        "ok": "11011",
        "ko": "11432"
    },
    "percentiles4": {
        "total": "12840",
        "ok": "12911",
        "ko": "12592"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2374,
    "percentage": 25
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 357,
    "percentage": 4
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 3561,
    "percentage": 37
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3298,
    "percentage": 34
},
    "meanNumberOfRequestsPerSecond": {
        "total": "43.991",
        "ok": "28.862",
        "ko": "15.128"
    }
}
    },"req_criac-a-o-ce502": {
        type: "REQUEST",
        name: "criação",
path: "criação",
pathFormatted: "req_criac-a-o-ce502",
stats: {
    "name": "criação",
    "numberOfRequests": {
        "total": "54636",
        "ok": "37238",
        "ko": "17398"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "46"
    },
    "maxResponseTime": {
        "total": "16076",
        "ok": "16076",
        "ko": "16002"
    },
    "meanResponseTime": {
        "total": "5080",
        "ok": "3894",
        "ko": "7617"
    },
    "standardDeviation": {
        "total": "4493",
        "ok": "4413",
        "ko": "3501"
    },
    "percentiles1": {
        "total": "4342",
        "ok": "1160",
        "ko": "9492"
    },
    "percentiles2": {
        "total": "10005",
        "ok": "9495",
        "ko": "10286"
    },
    "percentiles3": {
        "total": "11089",
        "ok": "10803",
        "ko": "11375"
    },
    "percentiles4": {
        "total": "12693",
        "ok": "12796",
        "ko": "12570"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 16949,
    "percentage": 31
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1893,
    "percentage": 3
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 18396,
    "percentage": 34
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 17398,
    "percentage": 32
},
    "meanNumberOfRequestsPerSecond": {
        "total": "250.624",
        "ok": "170.817",
        "ko": "79.807"
    }
}
    },"req_consulta-5d76b": {
        type: "REQUEST",
        name: "consulta",
path: "consulta",
pathFormatted: "req_consulta-5d76b",
stats: {
    "name": "consulta",
    "numberOfRequests": {
        "total": "29952",
        "ok": "27861",
        "ko": "2091"
    },
    "minResponseTime": {
        "total": "0",
        "ok": "0",
        "ko": "10000"
    },
    "maxResponseTime": {
        "total": "23478",
        "ok": "21348",
        "ko": "23478"
    },
    "meanResponseTime": {
        "total": "2339",
        "ok": "1648",
        "ko": "11540"
    },
    "standardDeviation": {
        "total": "4146",
        "ok": "3338",
        "ko": "2593"
    },
    "percentiles1": {
        "total": "16",
        "ok": "7",
        "ko": "10322"
    },
    "percentiles2": {
        "total": "2549",
        "ok": "889",
        "ko": "11491"
    },
    "percentiles3": {
        "total": "10400",
        "ok": "9983",
        "ko": "17339"
    },
    "percentiles4": {
        "total": "15842",
        "ok": "11664",
        "ko": "21552"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 20735,
    "percentage": 69
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 683,
    "percentage": 2
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6443,
    "percentage": 22
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2091,
    "percentage": 7
},
    "meanNumberOfRequestsPerSecond": {
        "total": "137.394",
        "ok": "127.803",
        "ko": "9.592"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
